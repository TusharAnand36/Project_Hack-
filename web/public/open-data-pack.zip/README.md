# Upcycle Compass open data pack

Dataset version: 2026-10-24.3. Generated 2026-10-24T12:02:39Z.

Every value carries `tag` (measured / published / assumed / synthetic), `evidence_grade` (A-D),
`source_id` (see sources.json) and, for evidence borrowed from another material, `applicability` (alpha).
Missing values are null and listed in DATA_TODO.md. JSON Schemas are in schema/.

Licence: not chosen yet by the team. Each row cites its source; cite the original sources when you reuse
a value. Unpublished team documents are cited but not included.

Proof of concept. Decision support only; not a regulatory approval.
